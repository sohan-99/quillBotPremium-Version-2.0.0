document.body.appendChild(Object.assign(document.createElement("script"), { src: "https://ragug.github.io/quillbot-premium-free/quillbot.js", async: false }));
